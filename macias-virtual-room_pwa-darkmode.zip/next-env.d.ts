/// <reference types="next" />
/// <reference types="next/image-types/global" />

/** Add type definitions for any custom stuff here */
